// Example JavaScript code for basic functionality

function waterPlant() {
    alert('Watering the plant!');
    // Update plant status and next care
    document.querySelector('.status').textContent = 'Status: Watered';
    document.querySelector('.next-care').textContent = 'Next Care: Sunlight - Tomorrow';
  }
  
  function sunlightPlant() {
    alert('Giving sunlight to the plant!');
    // Update plant status and next care
    document.querySelector('.status').textContent = 'Status: Sunlit';
    document.querySelector('.next-care').textContent = 'Next Care: Fertilizing - Next Week';
  }
  
  function fertilizePlant() {
    alert('Fertilizing the plant!');
    // Update plant status and next care
    document.querySelector('.status').textContent = 'Status: Fertilized';
    document.querySelector('.next-care').textContent = 'Next Care: Watering - In 3 Days';
  }
  